## PONG simple example for computer science
import pyxel
import random
from ball import Ball
from paddle import Paddle


def check_aabb_collision(x1, y1, w1, h1, x2, y2, w2, h2):
    # Returns True if the rectangles overlap
    return (
        x1 < x2 + w2 and
        x1 + w1 > x2 and
        y1 < y2 + h2 and
        y1 + h1 > y2
    )


def check_rect_circle_collision(rx, ry, rw, rh, cx, cy, radius):
    # 1. Find the closest point on the rectangle to the circle's center
    closest_x = max(rx, min(cx, rx + rw))
    closest_y = max(ry, min(cy, ry + rh))
    
    # 2. Calculate the distance between this closest point and the circle's center
    dist_x = cx - closest_x
    dist_y = cy - closest_y
    
    # 3. Use the Pythagorean distance squared to avoid slow square root operations
    distance_squared = (dist_x * dist_x) + (dist_y * dist_y)
    
    # 4. If the distance is less than the radius squared, they overlap
    return distance_squared < (radius * radius)

## Main app
class App:
    def __init__(self):
        pyxel.init(250, 250, "Pong", 60)
        
        self.scores = {
            "top": 0,
            "bottom": 0
        }

        self.ball = Ball(self)
        self.paddles = [Paddle(True), Paddle()]

        pyxel.run(self.update, self.draw)

    def update(self):
        self.ball.update()
        for p in self.paddles:
            p.update()
            # check collisions
            if check_rect_circle_collision(p.x, p.y, p.w, p.h, self.ball.x, self.ball.y, 4):
                self.ball.dy *= -1
                self.ball.dx += random.randrange(-3, 3) / 10
                self.ball.speed += 0.1

    def draw(self):
        pyxel.cls(0)
        self.ball.draw()
        for p in self.paddles:
            p.draw()
        pyxel.text(4, 4, str(self.scores["top"]), 7)
        pyxel.text(4, 238, str(self.scores["bottom"]), 7)
    
    def ball_entered_goal(self, bottom = False):
        if bottom:
            self.scores["top"] += 1
        else:
            self.scores["bottom"] += 1
        self.ball.reset()
        for p in self.paddles:
            p.reset()
        
App()
