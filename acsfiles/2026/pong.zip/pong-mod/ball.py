import pyxel
import random

## Helper functions
def normalize_vector(x, y):
    # 1. Get the length of the vector
    length = pyxel.sqrt(x * x + y * y)
    
    # 2. Prevent division by zero
    if length == 0:
        return 0, 0
        
    # 3. Divide by length to get the normalized vector
    return x / length, y / length

## Ball that bounces around the screen
class Ball:
    def __init__(self, app):
        self.app = app
        self.reset()
    
    def update(self):
        # normalize to get direction
        self.dx, self.dy = normalize_vector(self.dx, self.dy)
        # multiply by speed
        self.x += self.dx * self.speed
        self.y += self.dy * self.speed
        # check boundaries
        if self.x > 250 or self.x < 0:
            self.dx *= -1
        if self.y > 250:
            self.app.ball_entered_goal(True)
        elif self.y < 0:
            self.app.ball_entered_goal()
    
    def draw(self):
        pyxel.circ(self.x, self.y, 4, 7)
    
    def reset(self):
        self.x = 125
        self.y = 125
        self.dx = random.random() * 1.0
        self.dy = random.choice([1.0, -1.0])
        self.speed = 1.5