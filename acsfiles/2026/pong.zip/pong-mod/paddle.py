import pyxel

## Paddle that player moves
class Paddle:
    def __init__(self, bottom = False):
        self.bottom = bottom
        self.reset()
        if self.bottom:
            self.y = 230
        else:
            self.y = 20
        self.w = 32
        self.h = 6
        self.dx = 0

    def reset(self):
        self.x = 125 - 4

    def update(self):
        # input
        if self.bottom:
            if pyxel.btn(pyxel.KEY_LEFT):
                self.dx = -2
            elif pyxel.btn(pyxel.KEY_RIGHT):
                self.dx = 2
            else:
                self.dx = 0
        else:
            if pyxel.btn(pyxel.KEY_A):
                self.dx = -2
            elif pyxel.btn(pyxel.KEY_D):
                self.dx = 2
            else:
                self.dx = 0
        # movement
        _x = self.x + self.dx
        if _x > 0 and (_x + self.w) < 250:
            self.x = _x
        

    def draw(self):
        pyxel.rect(self.x, self.y, self.w, self.h, 7)
