# tools.py
# This file holds helpful functions for our quiz.


def say_hello():
    print("Welcome to the quiz!")


def is_correct(answer, right_answer):
    return answer.lower() == right_answer


def say_score(score, total):
    print("You got", score, "out of", total)


# TASK: Add a function to calculate the percentage and print it.
# How? Correct answers divided by total questions times 100.