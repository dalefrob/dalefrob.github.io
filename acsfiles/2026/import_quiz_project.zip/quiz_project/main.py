# main.py
# This is the file we run.
# It borrows code from the other two files using "import".

import questions
import tools

tools.say_hello()

score = 0

for q in questions.QUESTIONS:
    answer = input(q["question"] + " ")
    if tools.is_correct(answer, q["answer"]):
        print("Correct!")
        score = score + 1
    else:
        print("The answer was", q["answer"])

tools.say_score(score, len(questions.QUESTIONS))

# TASK: Ask and store the player's name. Congratulate the player at the end using their name.

# HARD TASK: Make a new jokes.py, import it, the have the program
# pick a random joke to show at the beginning of the quiz.

# DEMON TASK: Make the quiz have visuals using pyxel.