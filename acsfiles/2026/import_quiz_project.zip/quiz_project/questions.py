# questions.py
# This file just holds our quiz questions.

QUESTIONS = [
    {
        "question": "What is 2 + 2?",
        "answer": "4"
    },
    {
        "question": "What colour is the sky?",
        "answer": "blue"
    },
    {
        "question": "How many legs does a cat have?",
        "answer": "4"
    },
]

# TASK: Add 3 more questions!

# HARD TASK: Add multiple choice questions.

# DEMON TASK: Save and load question files to your computer.