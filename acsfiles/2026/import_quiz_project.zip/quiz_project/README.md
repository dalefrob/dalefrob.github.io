# My First Python Project

## What's in the folder?

```
quiz_project/
├── main.py        <- the file you run
├── questions.py   <- the questions
└── tools.py       <- helpful functions
```

## How to run it

Open the `quiz_project` folder, then run `main.py`.

## How do the files talk to each other?

At the top of `main.py` you will see:

```python
import questions
import tools
```

This means "borrow the code from `questions.py` and `tools.py`."
We don't write `.py` when we import.

After importing, we use a **dot** to reach inside a file:

- `questions.QUESTIONS` means the questions list inside `questions.py`
- `tools.say_hello()` means the say_hello function inside `tools.py`

## Challenges

1. Add a new question to `questions.py`, then run `main.py`.
2. Rename `tools.py` to `helpers.py`. What happens when you run it? Can you fix it?
3. Write a `say_goodbye()` function in `tools.py` and use it at the end of `main.py`.
