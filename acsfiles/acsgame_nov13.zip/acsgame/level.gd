extends Node2D
class_name Level

@export var checkpoint : Area2D
@export var exit : Area2D
@export var player : Player

var checkpoint_touched = false

func _ready() -> void:
	checkpoint.body_entered.connect(on_body_entered_checkpoint)
	player.died.connect(on_player_died)
	exit.body_entered.connect(on_exit_entered)
	
func on_body_entered_checkpoint(body):
	if body == player:
		checkpoint_touched = true

func on_exit_entered(body):
	if body == player:
		# Change level
		get_tree().change_scene_to_file("res://level2.tscn")

func on_player_died():
	if checkpoint_touched == true:
		player.position = checkpoint.position
	else:
		get_tree().reload_current_scene()
