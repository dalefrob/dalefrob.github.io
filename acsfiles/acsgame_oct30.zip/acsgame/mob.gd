extends CharacterBody2D
class_name Mob

const STATE_WALKING = 0
const STATE_DEAD = 1

var current_state = STATE_WALKING

var speed = 30
var direction = 1  # or -1

@onready var sprite := $AnimatedSprite2D
@onready var hitbox := $Hitbox
@onready var raycast_right := $RayCastRight
@onready var raycast_left := $RayCastLeft
@onready var audio := $AudioStreamPlayer2D

# Runs about 60 FPS
func _physics_process(_delta: float) -> void:
	if current_state == STATE_WALKING:
		walking_process()
	elif current_state == STATE_DEAD:
		dead_process()

func dead_process():
	velocity.y = velocity.y + 9.8
	move_and_slide()


func walking_process():
	velocity.x = speed * direction
	velocity.y = velocity.y + 9.8
	sprite.flip_h = (direction == -1) # evaluate to true or false
	move_and_slide()
	# Check for walls
	if is_on_wall():
		direction *= -1
		
	# Check for edges
	if direction == 1 and not raycast_right.is_colliding():
		direction *= -1
	elif direction == -1 and not raycast_left.is_colliding():
		direction *= -1
	
	# Check for player
	var bodies = hitbox.get_overlapping_bodies()
	for b in bodies:
		if b is Player:
			handle_hit_player(b)
			break

func handle_hit_player(player : Player):
	if player.velocity.y > 0:
		player.jump() 
		current_state = STATE_DEAD
		audio.play()
		set_collision_mask_value(1, false)
		sprite.play("hit")
		sprite.flip_v = true
		velocity.y = -100
	else:
		player.die()


func _on_visible_on_screen_notifier_2d_screen_exited() -> void:
	if current_state == STATE_DEAD:
		queue_free()
