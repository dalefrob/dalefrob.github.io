extends StaticBody2D

@export var coins_inside = 1

@onready var sprite : Sprite2D = $Sprite2D

func on_hit(player : Player):
	if coins_inside > 0:
		coins_inside -= 1
		player.collect()
		do_coin_effect()
	
	if coins_inside == 0:
		sprite.region_rect = Rect2(0, 16, 16, 16)


func do_coin_effect():
	var coin_sprite = Sprite2D.new()
	coin_sprite.texture = preload("res://sprites/coin.png")
	coin_sprite.region_enabled = true
	coin_sprite.region_rect = Rect2(0, 0, 16, 16)
	add_child(coin_sprite) 
	
	# Move the coin and delete it
	var tween = create_tween()
	
	tween.set_trans(Tween.TRANS_CUBIC) # NOTE added
	tween.set_ease(Tween.EASE_OUT) # NOTE added
	
	tween.tween_property(coin_sprite, "position:y", -16, 0.3)
	
	tween.set_parallel(true) # NOTE added
	tween.tween_method(bounce, 0.0, PI, 0.25) # NOTE added
	
	tween.play()
	await tween.finished
	coin_sprite.queue_free()

func bounce(value : float): # NOTE added
	var offset = -sin(value) * 8
	sprite.position.y = offset
