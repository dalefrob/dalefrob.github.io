extends StaticBody2D
class_name CoinBlock

@onready var sprite := $Sprite2D

func handle_collision(other_body):
	print("hit block")

func spawn_coin():
	pass
