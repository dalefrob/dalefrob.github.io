extends AnimatableBody2D
class_name MovingPlatform

@export var vertical : bool = false
@export var horizontal : bool = false 
@export var distance : int = 32
@export var phase_offset := PI / 2

@onready var original_position = position

var ticks = 0.0

func _physics_process(delta: float) -> void:
	ticks += delta
	var offset = Vector2.ZERO
	
	if vertical == true:
		offset.y = (cos(ticks + phase_offset) * distance)
	if horizontal: # same as horizontal == true
		offset.x = (sin(ticks + phase_offset) * distance)
	
	position = original_position + offset
