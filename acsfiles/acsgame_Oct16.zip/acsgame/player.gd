extends CharacterBody2D
class_name Player

const SPEED = 100.0
const JUMP_VELOCITY = -200.0

@onready var sprite = $AnimatedSprite2D
@onready var audioplayer := $AudioStreamPlayer2D

# Lesson 25/9
@export var coinlabel : Label
var coins : int = 0

# Happens every frame at a constant rate
func _physics_process(delta: float) -> void:
	# Move player down
	if not is_on_floor():
		velocity.y += 9.8

	# Handle jump.
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		jump()

	var direction := Input.get_axis("ui_left", "ui_right")
	if direction:
		sprite.play("run")
		velocity.x = direction * SPEED
		if direction < 0:
			sprite.flip_h = true
		else:
			sprite.flip_h = false
	else:
		velocity.x = 0
		sprite.play("default")
	
	move_and_slide()
	
	# TODO - Kill if we are too low
	if self.position.y > 128:
		die()

func jump():
	velocity.y = JUMP_VELOCITY


func die():
	# await get_tree().physics_frame # Prevent collision flushing
	get_tree().reload_current_scene()


func collect():
	coins += 1
	coinlabel.text = "Coins: " + str(coins)
	audioplayer.play()
