extends CharacterBody2D
class_name Mob

var speed = 30

var direction = 1  # or -1

@onready var sprite := $AnimatedSprite2D
@onready var hitbox := $Hitbox
@onready var raycast_right := $RayCastRight
@onready var raycast_left := $RayCastLeft

# Runs about 60 FPS
func _physics_process(delta: float) -> void:
	velocity.x = speed * direction
	velocity.y += 9.8
	sprite.flip_h = (direction == -1) # evaluate to true or false
	move_and_slide()
	# Check for walls
	if is_on_wall():
		direction *= -1
		
	# Check for edges
	if direction == 1 and not raycast_right.is_colliding():
		direction *= -1
	# TODO -- Check for left
	
	# Check for player
	var bodies = hitbox.get_overlapping_bodies()
	for b in bodies:
		if b is Player:
			handle_hit_player(b)
			break
	

func handle_hit_player(player : Player):
	if player.velocity.y > 0:
		player.jump() 
		queue_free()
	else:
		player.die()
